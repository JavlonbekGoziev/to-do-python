import tkinter as tk
from tkinter import messagebox, ttk
import json
import os

LOG_FILE = 'entries.json'


def load_entries():
    """Load entries from the log file."""
    if os.path.exists(LOG_FILE):
        with open(LOG_FILE, 'r') as file:
            return json.load(file)
    return []


def save_entries(entries):
    """Save entries to the log file."""
    with open(LOG_FILE, 'w') as file:
        json.dump(entries, file, indent=4)


class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List")
        self.root.geometry("600x600")
        self.root.config(bg="#f4f4f4")

        self.entries = load_entries()

        self.create_widgets()

    def create_widgets(self):
        """Create all widgets."""
        # Title label
        self.title_label = tk.Label(self.root, text="My To-Do List", font=("Helvetica", 24, "bold"), fg="#2c3e50", bg="#f4f4f4")
        self.title_label.pack(pady=20)

        # Search bar
        self.search_label = tk.Label(self.root, text="Search Tasks:", font=("Helvetica", 12), bg="#f4f4f4")
        self.search_label.pack(pady=5)
        self.search_entry = tk.Entry(self.root, font=("Helvetica", 12), width=40)
        self.search_entry.pack(pady=5)
        self.search_entry.bind("<KeyRelease>", self.search_tasks)

        # Listbox for tasks
        self.listbox_frame = tk.Frame(self.root, bg="#f4f4f4")
        self.listbox_frame.pack(pady=10)

        self.listbox_scrollbar = tk.Scrollbar(self.listbox_frame)
        self.listbox_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        self.listbox = tk.Listbox(self.listbox_frame, width=40, height=10, font=("Helvetica", 12), selectmode=tk.SINGLE, yscrollcommand=self.listbox_scrollbar.set, bd=0, highlightthickness=0)
        self.listbox.pack(side=tk.LEFT, fill=tk.BOTH, padx=10)
        self.listbox_scrollbar.config(command=self.listbox.yview)

        self.update_listbox()

        # Button frame for actions
        self.button_frame = tk.Frame(self.root, bg="#f4f4f4")
        self.button_frame.pack(pady=20)

        self.add_button = tk.Button(self.button_frame, text="Add Task", font=("Helvetica", 12), bg="#3498db", fg="white", width=15, height=2, command=self.add_task)
        self.add_button.grid(row=0, column=0, padx=10)

        self.delete_button = tk.Button(self.button_frame, text="Delete Task", font=("Helvetica", 12), bg="#e74c3c", fg="white", width=15, height=2, command=self.delete_task)
        self.delete_button.grid(row=0, column=1, padx=10)

        self.edit_button = tk.Button(self.button_frame, text="Edit Task", font=("Helvetica", 12), bg="#f39c12", fg="white", width=15, height=2, command=self.edit_task)
        self.edit_button.grid(row=1, column=0, padx=10, pady=10)

        self.complete_button = tk.Button(self.button_frame, text="Mark as Completed", font=("Helvetica", 12), bg="#2ecc71", fg="white", width=15, height=2, command=self.mark_completed)
        self.complete_button.grid(row=1, column=1, padx=10, pady=10)

        self.download_button = tk.Button(self.button_frame, text="Download Tasks", font=("Helvetica", 12), bg="#2980b9", fg="white", width=15, height=2, command=self.download_tasks)
        self.download_button.grid(row=2, column=0, columnspan=2, padx=10, pady=10)

    def update_listbox(self):
        """Update the listbox with current tasks."""
        self.listbox.delete(0, tk.END)
        for index, entry in enumerate(self.entries):
            task_label = f"{entry['content']} - {entry.get('remainder_time', 'No reminder')}"
            if entry.get('completed', False):
                task_label = f"[Completed] {task_label}"
            self.listbox.insert(tk.END, task_label)

    def add_task(self):
        """Add a new task."""
        new_window = tk.Toplevel(self.root)
        new_window.title("Add Task")
        new_window.geometry("400x350")
        new_window.config(bg="#ecf0f1")

        content_label = tk.Label(new_window, text="Task Content:", font=("Helvetica", 12), bg="#ecf0f1")
        content_label.pack(pady=10)

        content_entry = tk.Entry(new_window, font=("Helvetica", 12), width=40)
        content_entry.pack(pady=5)

        reminder_label = tk.Label(new_window, text="Reminder Time (optional):", font=("Helvetica", 12), bg="#ecf0f1")
        reminder_label.pack(pady=10)

        reminder_options = ["No Reminder", "10 minutes", "30 minutes", "1 hour", "2 hours", "Tomorrow"]
        reminder_combobox = ttk.Combobox(new_window, values=reminder_options, font=("Helvetica", 12), width=40)
        reminder_combobox.set("No Reminder")
        reminder_combobox.pack(pady=5)

        priority_label = tk.Label(new_window, text="Priority:", font=("Helvetica", 12), bg="#ecf0f1")
        priority_label.pack(pady=10)

        priority_options = ["Low", "Medium", "High"]
        priority_combobox = ttk.Combobox(new_window, values=priority_options, font=("Helvetica", 12), width=40)
        priority_combobox.set("Low")
        priority_combobox.pack(pady=5)

        def save_task():
            content = content_entry.get()
            reminder = reminder_combobox.get()
            priority = priority_combobox.get()

            if content:
                new_entry = {'content': content, 'remainder_time': reminder, 'priority': priority, 'completed': False}
                self.entries.append(new_entry)
                save_entries(self.entries)
                self.update_listbox()
                new_window.destroy()
            else:
                messagebox.showerror("Error", "Task content cannot be empty.")

        save_button = tk.Button(new_window, text="Save Task", font=("Helvetica", 12), bg="#3498db", fg="white", width=15, height=2, command=save_task)
        save_button.pack(pady=20)

    def delete_task(self):
        """Delete the selected task."""
        selected_task_index = self.listbox.curselection()
        if selected_task_index:
            selected_index = selected_task_index[0]
            del self.entries[selected_index]
            save_entries(self.entries)
            self.update_listbox()
        else:
            messagebox.showwarning("Warning", "Please select a task to delete.")

    def edit_task(self):
        """Edit the selected task."""
        selected_task_index = self.listbox.curselection()
        if selected_task_index:
            selected_index = selected_task_index[0]
            entry = self.entries[selected_index]

            new_window = tk.Toplevel(self.root)
            new_window.title("Edit Task")
            new_window.geometry("400x350")
            new_window.config(bg="#ecf0f1")

            content_label = tk.Label(new_window, text="Task Content:", font=("Helvetica", 12), bg="#ecf0f1")
            content_label.pack(pady=10)

            content_entry = tk.Entry(new_window, font=("Helvetica", 12), width=40)
            content_entry.insert(0, entry['content'])
            content_entry.pack(pady=5)

            reminder_label = tk.Label(new_window, text="Reminder Time (optional):", font=("Helvetica", 12), bg="#ecf0f1")
            reminder_label.pack(pady=10)

            reminder_options = ["No Reminder", "10 minutes", "30 minutes", "1 hour", "2 hours", "Tomorrow"]
            reminder_combobox = ttk.Combobox(new_window, values=reminder_options, font=("Helvetica", 12), width=40)
            reminder_combobox.set(entry.get('remainder_time', "No Reminder"))
            reminder_combobox.pack(pady=5)

            priority_label = tk.Label(new_window, text="Priority:", font=("Helvetica", 12), bg="#ecf0f1")
            priority_label.pack(pady=10)

            priority_options = ["Low", "Medium", "High"]
            priority_combobox = ttk.Combobox(new_window, values=priority_options, font=("Helvetica", 12), width=40)
            priority_combobox.set(entry.get('priority', "Low"))
            priority_combobox.pack(pady=5)

            def save_edited_task():
                content = content_entry.get()
                reminder = reminder_combobox.get()
                priority = priority_combobox.get()

                if content:
                    self.entries[selected_index] = {'content': content, 'remainder_time': reminder, 'priority': priority, 'completed': entry.get('completed', False)}
                    save_entries(self.entries)
                    self.update_listbox()
                    new_window.destroy()
                else:
                    messagebox.showerror("Error", "Task content cannot be empty.")

            save_button = tk.Button(new_window, text="Save Changes", font=("Helvetica", 12), bg="#3498db", fg="white", width=15, height=2, command=save_edited_task)
            save_button.pack(pady=20)
        else:
            messagebox.showwarning("Warning", "Please select a task to edit.")

    def mark_completed(self):
        """Mark the selected task as completed."""
        selected_task_index = self.listbox.curselection()
        if selected_task_index:
            selected_index = selected_task_index[0]
            self.entries[selected_index]['completed'] = True
            save_entries(self.entries)
            self.update_listbox()
        else:
            messagebox.showwarning("Warning", "Please select a task to mark as completed.")

    def download_tasks(self):
        """Download tasks as a .txt file."""
        if self.entries:
            with open('tasks.txt', 'w') as file:
                for index, entry in enumerate(self.entries):
                    task_label = f"Task {index + 1}:\n"
                    task_label += f"Content: {entry['content']}\n"
                    task_label += f"Reminder Time: {entry.get('remainder_time', 'No reminder')}\n"
                    task_label += f"Priority: {entry.get('priority', 'Low')}\n"
                    task_label += f"Status: {'Completed' if entry.get('completed', False) else 'Pending'}\n"
                    task_label += "-" * 30 + "\n"
                    file.write(task_label)
            messagebox.showinfo("Success", "Tasks downloaded as tasks.txt")
        else:
            messagebox.showwarning("Warning", "There are no tasks to download.")

    def search_tasks(self, event):
        """Filter tasks based on search input."""
        search_text = self.search_entry.get().lower()
        self.listbox.delete(0, tk.END)
        for index, entry in enumerate(self.entries):
            if search_text in entry['content'].lower():
                task_label = f"{entry['content']} - {entry.get('remainder_time', 'No reminder')}"
                if entry.get('completed', False):
                    task_label = f"[Completed] {task_label}"
                self.listbox.insert(tk.END, task_label)


def run_app():
    """Run the application."""
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()


if __name__ == "__main__":
    run_app()
